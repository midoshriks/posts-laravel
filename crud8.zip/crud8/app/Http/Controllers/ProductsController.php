<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;

class ProductsController extends Controller
{
    public function index(){
        $productsdata = Products::all();
        return view('products.productsdata',compact('productsdata'));
    }

    public function plusproduct(){
        return view('products.plusproduct');
    }

    public function inserproduct(Request $request){
        $productsdata = Products::create($request->all());
        if($request->hasFile('foto')){
            $request->file('foto')->move('fotoproducts/',$request->file('foto')->getClientOriginalName());
            $productsdata->foto =$request->file('foto')->getClientOriginalName();
            $productsdata->save();
        }
        return redirect()->route('productsdata')->with('success','Data has been insert product successfully');
    }
}
