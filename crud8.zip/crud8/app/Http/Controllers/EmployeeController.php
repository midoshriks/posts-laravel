<?php

namespace App\Http\Controllers;

use App\Models\Employee;
// use Facade\FlareClient\Stacktrace\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class EmployeeController extends Controller
{
    public function index(){
        $data = Employee::all();
        // dd($data);
        // return view('datapage',$data);
        return view('datapage',compact('data'));
    }

    public function plusdata(){
        return view('plusdata');
    }

    public function insertdata(Request $request){
        // dd($request->all());
        $data = Employee::create($request->all());
        if($request->hasFile('foto')){
            $request->file('foto')->move('fotodatapage/',$request->file('foto')->getClientOriginalName());
            $data->foto =$request->file('foto')->getClientOriginalName();
            $data->save();
        }
        return redirect()->route('datapage')->with('success','Data has been registered successfully');
    }

    public function editdata($id){
        $data = Employee::find($id);
        // dd($data);
        return view('editdata', compact('data'));
    }

    public function update(Request $request, $id){
        $data = Employee::find($id);
        $data->update($request->all());
        return redirect()->route('datapage')->with('success','Data has been Update successfully');
    }

    public function delete($id){
        $data = Employee::find($id);
        $data->delete();
        return redirect()->route('datapage')->with('delete','Data has been registered Delete');
    }
}
