<?php

use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\ProductsController;
use App\Models\Employee;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Show table data
Route::get('/datapage', [EmployeeController::class, 'index'])->name('datapage');

// forme in insert data
Route::get('/plusdata', [EmployeeController::class, 'plusdata'])->name('plusdata');
Route::post('/insertdata', [EmployeeController::class, 'insertdata'])->name('insertdata');

// forme in Update data
Route::get('/editdata/{id}', [EmployeeController::class, 'editdata'])->name('editdata');
Route::post('/update/{id}', [EmployeeController::class, 'update'])->name('update');

// forme in delete data
Route::get('/delete/{id}', [EmployeeController::class, 'delete'])->name('delete');


// ================================== test products ================================================
Route::get('/productsdata', [ProductsController::class, 'index'])->name('productsdata');
// forme in insert data
Route::get('/plusproduct', [ProductsController::class, 'plusproduct'])->name('plusproduct');
Route::post('/inserproduct', [ProductsController::class, 'inserproduct'])->name('inserproduct');

